fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Lias82'
description 'Waschanlagen-Skript für FiveM mit Zahlungssystem'
version '1.0.1'

client_script 'waschanlage.lua'
server_script 'server.lua'
