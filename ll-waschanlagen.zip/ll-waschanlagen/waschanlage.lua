-- Waschanlagen Standorte
local washStations = {
    {x = 26.59, y = -1391.92, z = 28.36},
    {x = 174.92, y = -1736.73, z = 28.36},
    {x = -74.56, y = 6427.87, z = 30.44}
}

local washPrice = 0

Citizen.CreateThread(function()
    for _, station in ipairs(washStations) do
        local blip = AddBlipForCoord(station.x, station.y, station.z)
        SetBlipSprite(blip, 100)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.8)
        SetBlipColour(blip, 3)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Waschanlage")
        EndTextCommandSetBlipName(blip)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        for _, station in ipairs(washStations) do
            local distance = #(playerCoords - vector3(station.x, station.y, station.z))
            if distance < 5.0 then
                DrawText3D(station.x, station.y, station.z + 1.0, "Drücke ~g~E~w~, um dein Fahrzeug zu waschen")
                if IsControlJustReleased(0, 38) then -- Taste E
                    local vehicle = GetVehiclePedIsIn(playerPed, false)
                    if vehicle ~= 0 then
                        TriggerEvent("chatMessage", "Waschanlage", {0, 255, 0}, "Dein Fahrzeug wird gewaschen...")
                        StartWaterEffect(vehicle)
                        Citizen.Wait(5000)
                        WashDecalsFromVehicle(vehicle, 1.0)
                        SetVehicleDirtLevel(vehicle, 0.0)
                        StopWaterEffect()
                        TriggerEvent("chatMessage", "Waschanlage", {0, 255, 0}, "Dein Fahrzeug ist jetzt sauber!")
                    else
                        TriggerEvent("chatMessage", "Waschanlage", {255, 0, 0}, "Du musst in einem Fahrzeug sein!")
                    end
                end
            end
        end
    end
end)

function StartWaterEffect(vehicle)
    local coords = GetEntityCoords(vehicle)

    -- Lade den Wasser-Particle-Effekt
    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do
        Citizen.Wait(0)
    end
    UseParticleFxAsset("core")

    local directions = {
        {x = 1.5, y = 0.0, z = 1.5},   -- Rechts vorne
        {x = -1.5, y = 0.0, z = 1.5},  -- Links vorne
        {x = 0.0, y = 1.5, z = 1.5},   -- Rechts
        {x = 0.0, y = -1.5, z = 1.5},  -- Links
        {x = 1.5, y = 1.5, z = 1.5},   -- Rechts hinten
        {x = -1.5, y = -1.5, z = 1.5}  -- Links hinten
    }

    for _, dir in ipairs(directions) do
        local xPos = coords.x + dir.x
        local yPos = coords.y + dir.y
        local zPos = coords.z + dir.z

        local waterEffect = StartParticleFxLoopedAtCoord("ent_sht_water", xPos, yPos, zPos, 0.0, 0.0, 0.0, 3.0, false, false, false, false)
    end

    -- Debugging: Bestätigen, dass der Partikeleffekt gestartet wurde
    print("Fahrzeug Wäsche Gestartet")

    -- Stoppe den Effekt nach 5 Sekunden
    Citizen.SetTimeout(5000, function()
        -- Stoppe alle Partikelströme (dies müsste ggf. optimiert werden, wenn mehrere Partikelinstanzen benötigt werden)
        StopParticleFxLooped(waterEffect, 0)

        -- Debugging: Bestätigen, dass der Partikeleffekt gestoppt wurde
        print("Fahrzeug Gewaschen!")
    end)
end







function StopWaterEffect()
    RemoveParticleFxFromEntity(PlayerPedId())
end

function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end